"""Content-independent validation for the twenty-essay migration.

Structural checks do not replace independent prose/fact review or Obsidian rendering.
"""
from pathlib import Path
import argparse, hashlib, json, re, yaml, zipfile

WORK = Path('/tmp/methodology-rewrite-NEOldi')
VAULT = Path('/Volumes/DataSSD/Documents/Alex-投资方法论')
TITLES = json.loads((WORK / 'titles.json').read_text())
TAGS = set('估值 价值投资 成长股 逆向投资 长期持有 护城河 投资体系 泡沫 牛熊周期 市场底部 市场情绪 景气行情 政策周期 杠杆 交易心理 认知 AI AI算力 比特币 黄金 宏观货币 公司战略 基金经理 伟志思考'.split())
FIELDS = {'type', 'author', 'date', 'tags', 'aliases', 'rating'}
BANNED = re.compile(r'吴伟志|中欧瑞博|伟志思考|原文|原作者|本次整理|待核|证据边界|\bC\d{3}\b|方法\s*0\d')

def metadata(text):
    return yaml.safe_load(text.split('---', 2)[1])

def body(text):
    return text.split('\n## 相关\n')[0]

def wikilinks(text):
    text = re.sub(r'```.*?```', '', text, flags=re.S)
    text = re.sub(r'`[^`\n]*`', '', text)
    return re.findall(r'\[\[([^\]]+)\]\]', text)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    staged = WORK / 'staged'
    sources = {str(p.relative_to(VAULT)): p for p in VAULT.rglob('*') if p.is_file() and not any(part.startswith('.') for part in p.relative_to(VAULT).parts)}
    if not args.live:
        sources.update({str(p.relative_to(staged)): p for p in staged.rglob('*') if p.is_file()})
    targets = set()
    for rel, path in sources.items():
        targets.update((rel, str(Path(rel).with_suffix('')), path.name, path.stem))
        if path.suffix == '.md':
            try:
                for alias in metadata(path.read_text()).get('aliases') or []:
                    targets.add(str(alias))
            except Exception:
                pass
    # Archive is created after staging review; a staged reader link is expected to resolve on installation.
    if not args.live:
        targets.add('methodology-rewrite-workpapers-20260914.zip')
    errors, stats = [], []
    new_links = {}
    for title in TITLES:
        rel = f'方法论/{title}.md'
        if rel not in sources:
            errors.append(f'Missing method: {title}')
            continue
        text = sources[rel].read_text()
        try:
            meta = metadata(text)
            assert set(meta) == FIELDS, 'six fields'
            assert meta['type'] == '方法论'
            assert meta['author'] is None and meta['date'] is None and meta['rating'] is None
            assert isinstance(meta['aliases'], list)
            assert 1 <= len(meta['tags']) <= 3
            assert set(meta['tags']) <= TAGS
        except Exception as error:
            errors.append(f'{title}: invalid metadata {error}')
        if BANNED.search(text):
            errors.append(f'{title}: forbidden reader wording {BANNED.search(text).group()}')
        if f'\n# {title}\n' not in text:
            errors.append(f'{title}: missing matching title')
        if text.count('\n## 相关\n') != 1:
            errors.append(f'{title}: related section count')
            continue
        related = text.split('\n## 相关\n')[1]
        concept_names = {p.stem for p in (VAULT / 'concepts').glob('*.md')}
        links = [x.split('|')[0].split('#')[0] for x in wikilinks(related)]
        if not (set(links) & concept_names):
            errors.append(f'{title}: no concept link')
        direct = [x for x in links if x not in concept_names and x != '投资方法论合集']
        if len(direct) > 5:
            errors.append(f'{title}: more than 5 article links')
        new_links[title] = direct
        definitions = re.findall(r'^\[\^([^]]+)\]:', text, re.M)
        refs = re.findall(r'\[\^([^]]+)\]', re.sub(r'^\[\^[^]]+\]:.*$', '', text, flags=re.M))
        if set(definitions) != set(refs) or len(definitions) != len(set(definitions)):
            errors.append(f'{title}: footnote definitions/references mismatch')
        for target in wikilinks(text):
            target = target.split('|')[0].split('#')[0]
            if target and target not in targets:
                errors.append(f'{title}: unresolved {target}')
        content = body(text).split('---', 2)[-1]
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', content))
        if chinese_chars < 1800:
            errors.append(f'{title}: unexpectedly short {chinese_chars} Chinese chars')
        # The essays should not accidentally contain malformed inline TeX or unclosed blocks.
        if re.search(r'(?<!\$)\([^\n]*\\(?:approx|frac|times)', text):
            errors.append(f'{title}: apparent unrendered inline TeX')
        if text.count('$$') % 2:
            errors.append(f'{title}: unmatched display-math delimiter')
        stats.append({'title': title, 'chinese_chars': chinese_chars, 'paragraphs': len(content.split('\n\n')), 'h2': len(re.findall(r'^## ', content, re.M)), 'footnotes': len(definitions), 'article_links': len(direct)})

    for title, direct in new_links.items():
        for target in direct:
            rel = f'方法论/{target}.md'
            if rel not in sources:
                continue
            counterpart = sources[rel].read_text().split('\n## 相关\n')[-1]
            backlinks = [x.split('|')[0].split('#')[0] for x in wikilinks(counterpart)]
            if title not in backlinks:
                errors.append(f'{title} -> {target}: missing reciprocal related link')

    manifest_path = WORK / 'migration-manifest.json'
    if manifest_path.exists():
        for item in json.loads(manifest_path.read_text()):
            rel = item['path']
            if rel not in sources:
                errors.append(f'Manifest file missing: {rel}')
                continue
            current = sources[rel].read_bytes()
            if hashlib.sha256(current).hexdigest() != item['after_sha256']:
                errors.append(f'Hash differs from approved staging: {rel}')
            if rel.endswith('.md'):
                for link in wikilinks(current.decode()):
                    target = link.split('|')[0].split('#')[0]
                    if target and target not in targets:
                        errors.append(f'{rel}: unresolved {target}')
                    if re.search(r'投资方法论合集#记录 C\d+', link):
                        errors.append(f'{rel}: old case anchor')

    preserved_path = WORK / 'unchanged-bodies.json'
    if preserved_path.exists():
        for rel, original_hash in json.loads(preserved_path.read_text()).items():
            current_hash = hashlib.sha256(body(sources[rel].read_text()).encode()).hexdigest()
            if current_hash != original_hash:
                errors.append(f'Unrelated article body changed: {rel}')

    canvas = json.loads(sources['投资方法论体系.canvas'].read_text())
    ids = [node['id'] for node in canvas['nodes']]
    if len(ids) != len(set(ids)):
        errors.append('Canvas duplicate node ID')
    for node in canvas['nodes']:
        if node['type'] == 'file' and node['file'] not in sources:
            errors.append(f'Canvas target missing: {node["file"]}')
        if 'subpath' in node and '记录 C' in node['subpath']:
            errors.append('Canvas old record subpath')
    for edge in canvas['edges']:
        if edge['fromNode'] not in ids or edge['toNode'] not in ids:
            errors.append('Canvas missing endpoint')

    coverage_files = sorted((WORK / 'reviews').glob('coverage-*.json'))
    coverage_count = None
    if len(coverage_files) == 3:
        records = []
        for path in coverage_files:
            payload = json.loads(path.read_text())
            if isinstance(payload, dict):
                payload = next((payload[k] for k in ('articles', 'entries', 'items', 'records', 'coverage', 'sources') if k in payload), [])
            records.extend(payload)
        coverage_count = len(records)
        if coverage_count != 138:
            errors.append(f'Coverage requires 138 records, got {coverage_count}')
        names = [x['source'] for x in records]
        if len(names) != len(set(names)):
            errors.append('Duplicate source in responsibility coverage maps')
        expected_sources = set()
        for letter in 'abc':
            expected_sources.update(json.loads((WORK / f'read-{letter}.json').read_text()))
        if set(names) != expected_sources:
            errors.append(f'Coverage mismatch: missing {expected_sources-set(names)}, extra {set(names)-expected_sources}')
        covered_methods = set()
        for record in records:
            methods = record.get('methods', record.get('method_ids', record.get('targets', [])))
            if not methods or any(n not in range(1, 21) for n in methods):
                errors.append(f'Invalid method destinations: {record["source"]}')
            covered_methods.update(methods)
            retained = record.get('retained', record.get('unique_logic_or_counterexample', record.get('logic_destination', record.get('unique_logic', ''))))
            omitted = record.get('omitted', record.get('omitted_case_reason', record.get('omitted_cases_reason', record.get('omitted_cases', ''))))
            if not retained or not omitted:
                errors.append(f'Coverage missing reasoning or case treatment: {record["source"]}')
        if covered_methods != set(range(1, 21)):
            errors.append(f'Method coverage incomplete: {set(range(1,21))-covered_methods}')
    else:
        errors.append(f'Need all 3 coverage maps, got {len(coverage_files)}')

    report = {'mode': 'live' if args.live else 'staged', 'methods': len(stats), 'total_chinese_chars': sum(x['chinese_chars'] for x in stats), 'coverage_records': coverage_count, 'preserved_other_article_bodies': len(json.loads(preserved_path.read_text())) if preserved_path.exists() else None, 'errors': errors, 'stats': stats}
    output = WORK / 'reviews' / ('validation-live.json' if args.live else 'validation-staged.json')
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(bool(errors))

if __name__ == '__main__':
    main()
