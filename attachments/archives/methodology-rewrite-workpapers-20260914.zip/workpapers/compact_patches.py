from pathlib import Path
import hashlib, json, difflib, zipfile
work = Path('/tmp/methodology-rewrite-NEOldi')
vault = Path('/Volumes/DataSSD/Documents/Alex-投资方法论')
paths = []
for n, item in enumerate(json.loads((work / 'migration-manifest.json').read_text())):
    path = vault / item['path']
    old = path.read_text() if path.exists() else None
    if old is not None and hashlib.sha256(path.read_bytes()).hexdigest() == item['after_sha256']:
        continue
    assert (hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None) == item['before_sha256']
    new = (work / 'staged' / item['path']).read_text()
    if item['path'] == '方法论/投资方法论合集.md':
        paths.extend([str(work / 'patches' / f'{n:02d}-delete.patch'), str(work / 'patches' / f'{n:02d}.patch')])
        continue
    patch = ['*** Begin Patch']
    if old is None:
        patch += [f'*** Add File: {path}'] + ['+' + line for line in new.splitlines()]
    else:
        patch += [f'*** Update File: {path}']
        delta = list(difflib.unified_diff(old.splitlines(), new.splitlines(), n=3))[2:]
        patch += ['@@' if line.startswith('@@') else line for line in delta]
    patch += ['*** End Patch']
    dest = work / 'patches' / f'{n:02d}-compact.patch'
    dest.write_text('\n'.join(patch) + '\n')
    paths.append(str(dest))
print(json.dumps(paths))
