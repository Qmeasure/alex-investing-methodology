from pathlib import Path
import json, hashlib, zipfile, argparse

WORK = Path('/tmp/methodology-rewrite-NEOldi')
VAULT = Path('/Volumes/DataSSD/Documents/Alex-投资方法论')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['patches', 'archive-workpapers'])
    args = parser.parse_args()
    manifest = json.loads((WORK / 'migration-manifest.json').read_text())
    archive_path = VAULT / 'attachments/archives/methodology-rewrite-workpapers-20260914.zip'
    if args.mode == 'patches':
        with zipfile.ZipFile(archive_path) as archive:
            assert archive.testzip() is None
            for item in manifest:
                if item['before_sha256']:
                    saved = archive.read('previous_version/' + item['path'])
                    assert hashlib.sha256(saved).hexdigest() == item['before_sha256']
                    assert (VAULT / item['path']).read_bytes() == saved
        patch_dir = WORK / 'patches'
        patch_dir.mkdir(exist_ok=True)
        for n, item in enumerate(manifest):
            path = VAULT / item['path']
            new = (WORK / 'staged' / item['path']).read_text()
            patch = ['*** Begin Patch']
            if item['path'] == '方法论/投资方法论合集.md':
                (patch_dir / f'{n:02d}-delete.patch').write_text(f'*** Begin Patch\n*** Delete File: {path}\n*** End Patch\n')
                patch += [f'*** Add File: {path}'] + ['+' + x for x in new.splitlines()]
            elif item['before_sha256'] is None:
                patch += [f'*** Add File: {path}'] + ['+' + x for x in new.splitlines()]
            else:
                patch += [f'*** Update File: {path}', '@@'] + ['-' + x for x in path.read_text().splitlines()] + ['+' + x for x in new.splitlines()]
            patch += ['*** End Patch']
            (patch_dir / f'{n:02d}.patch').write_text('\n'.join(patch) + '\n')
        print(json.dumps([str(p) for p in sorted(patch_dir.glob('*.patch'))]))
    else:
        paths = []
        for folder in ('reviews', 'evidence'):
            paths.extend(p for p in (WORK / folder).rglob('*') if p.is_file())
        paths.extend(WORK / name for name in ('build_migration.py', 'validate.py', 'finalize.py', 'compact_patches.py', 'titles.json', 'migration-config.json', 'migration-manifest.json'))
        # Refresh only our workpapers, preserving recovery member bytes exactly.
        with zipfile.ZipFile(archive_path) as archive:
            retained = {name: archive.read(name) for name in archive.namelist() if not name.startswith('workpapers/')}
        pending = archive_path.with_suffix('.pending.zip')
        assert not pending.exists()
        with zipfile.ZipFile(pending, 'x', zipfile.ZIP_DEFLATED) as archive:
            for name, data in retained.items():
                archive.writestr(name, data)
            for path in paths:
                archive.write(path, 'workpapers/' + str(path.relative_to(WORK)))
        with zipfile.ZipFile(pending) as archive:
            assert archive.testzip() is None
            assert all(archive.read(name) == data for name, data in retained.items())
        pending.replace(archive_path)
        with zipfile.ZipFile(archive_path) as archive:
            assert archive.testzip() is None
            for item in manifest:
                if item['before_sha256']:
                    assert hashlib.sha256(archive.read('previous_version/' + item['path'])).hexdigest() == item['before_sha256']
        print(f'Archived {len(paths)} workpapers; all previous-version hashes match.')

if __name__ == '__main__':
    main()
