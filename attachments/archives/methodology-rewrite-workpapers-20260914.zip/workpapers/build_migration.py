"""Prepare a reviewable apply_patch; preserve old reader files in a recoverable ZIP.

This script does not modify Vault Markdown or Canvas. Run only once drafts pass review.
"""
from pathlib import Path
import json, re, hashlib, zipfile, argparse

WORK = Path('/tmp/methodology-rewrite-NEOldi')
VAULT = Path('/Volumes/DataSSD/Documents/Alex-投资方法论')
TITLES = json.loads((WORK / 'titles.json').read_text())
CONFIG = json.loads((WORK / 'migration-config.json').read_text())
NAV = '投资方法论合集'
ARCHIVE = 'attachments/archives/methodology-rewrite-workpapers-20260914.zip'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def build():
    changes = {}
    incoming = {n: {} for n in range(1, 21)}
    pattern = re.compile(r'^- \[\[投资方法论合集#记录 (C\d+)\|[^\]]+\]\].*$', re.M)
    for path in sorted((VAULT / '方法论').glob('*.md')):
        if path.stem == NAV:
            continue
        old = path.read_text()
        if not pattern.search(old):
            continue
        assert '\n## 相关\n' in old, path
        body, related = old.split('\n## 相关\n', 1)
        assert not pattern.search(body), path
        def replacement(match):
            n, reason = CONFIG['legacy_targets'][match.group(1)]
            if '吴伟志' not in path.stem and '伟志思考' not in path.stem:
                incoming[n].setdefault(path.stem, reason)
            return f'- [[{TITLES[n-1]}]] — 呼应：{reason}'
        related = pattern.sub(replacement, related)
        # Merge duplicate target entries introduced by mapping several old records to one method.
        seen, lines = set(), []
        for line in related.splitlines():
            match = re.match(r'^- \[\[([^]|]+)(?:\|[^]]+)?\]\]', line)
            key = match.group(1) if match else None
            if key in seen:
                continue
            if key:
                seen.add(key)
            lines.append(line)
        changes[str(path.relative_to(VAULT))] = body + '\n## 相关\n' + '\n'.join(lines).rstrip() + '\n'

    links = {n: [] for n in range(1, 21)}
    for a, b, reason in CONFIG['relations']:
        links[a].append((TITLES[b-1], reason))
        links[b].append((TITLES[a-1], reason))
    for n, title in enumerate(TITLES, 1):
        draft = (WORK / 'drafts' / f'{title}.md').read_text()
        body, related = draft.split('\n## 相关\n', 1)
        concept_lines = [line for line in related.splitlines() if line.startswith('- 概念')]
        assert len(concept_lines) == 1, title
        direct = links[n] + list(incoming[n].items())
        assert len(direct) <= 5, (title, direct)
        related_lines = concept_lines + [f'- [[{target}]] — 呼应：{reason}' for target, reason in direct]
        related_lines += [f'- [[{NAV}]] — 返回二十篇方法论导航。']
        changes[f'方法论/{title}.md'] = body + '\n## 相关\n\n' + '\n'.join(related_lines) + '\n'

    nav = '''---
type: 索引
author:
date:
tags:
  - 投资体系
aliases:
  - 投资方法论导航
rating:
---

# 投资方法论合集

投资中的问题彼此相连：先弄清自己靠什么赚钱，才能判断企业与价格；理解市场和资金的变化，才能选择仓位与行动。这二十篇文章沿着这条思路展开。每篇都从具体困惑出发，讲清原因、决策中的取舍，以及方法不能解决什么，可以连续阅读，也可以带着眼前的问题单独阅读。

## 投资体系与研究

- [[先选定自己的投资流派]] — 价值、成长和趋势各在赚什么钱，为什么不能在买入后临时换一套理由。
- [[收益究竟从哪里来]] — 分清盈利增长、估值变化和现金分红，判断回报的来源能否延续。
- [[如何过滤信息并形成判断]] — 把新闻、经营事实与市场价格连接成可以检验、能够纠错的判断。
- [[投资原则为什么不等于固定策略]] — 哪些约束必须坚持，哪些做法应随市场条件调整。

## 企业与估值

- [[好公司为什么不一定是好投资]] — 企业优秀与价格合适是两道判断，未来增长也可能被提前支付。
- [[成长从哪里来、能持续多久]] — 从需求、份额、定价权、利润率和再投资，追问成长最终归谁所有。
- [[周期高利润为什么容易制造低估值幻觉]] — 供需与扩产怎样改变利润，为什么繁荣时的低市盈率可能最不可靠。
- [[如何识别信用风险与价值陷阱]] — 从交易实质、现金回收和债务安排，判断便宜背后究竟剩下什么。

## 市场与周期

- [[经济、政策与股价为什么不同步]] — 政策怎样经过信用与需求传导，股价又为何可能领先或偏离经营。
- [[如何判断市场所处阶段]] — 把估值、盈利、政策和资金行为放在一起，理解春播、夏长、秋收与冬藏。
- [[为什么指数与行业、个股各有牛熊]] — 指数是结构和权重的结果，不能替代对具体资产的判断。
- [[第二层次思维如何识别预期差]] — 不仅判断会发生什么，还要判断价格已经相信了什么。

## 资金与风险

- [[资金供需怎样推动行情]] — 资金来自哪里、为什么进入、能否留下，如何影响边际成交价格。
- [[一致预期如何演变成拥挤交易]] — 看好与继续买入并非同一件事，持仓越一致，退出越需要对手方。
- [[杠杆为什么会改变下跌的性质]] — 抵押品、保证金和被迫出售如何把普通回调变成连锁收缩。
- [[资产负债表如何形成收缩循环]] — 一家的节省怎样成为另一家的收入下降，修复需要解除哪些约束。

## 决策与执行

- [[仓位如何匹配判断与承受能力]] — 把研究把握、资金期限、相关风险和可承受损失放进同一次决策。
- [[长期持有、减仓和止损如何取舍]] — 区分暂时波动、价值变化和资金约束，解释何时等、何时收、何时认错。
- [[为什么接受不完美才能坚持正确]] — 接受错过和短期不顺，但不替失效的判断寻找借口。
- [[如何通过情景推演与复盘修正判断]] — 在事前设想不同路径，在事后检验当时的理由，而非追认结果。

## 相关

- 概念：[[投资体系]] · [[估值]] · [[牛熊周期]] · [[仓位管理]] · [[认知]]
- [[投资方法论体系.canvas|投资方法论体系图]] — 按投资决策流程查看概念与代表文章。
'''
    changes[f'方法论/{NAV}.md'] = nav
    home = (VAULT / 'Home.md').read_text()
    old_entry = '- `方法论/` — 全部方法论文章(扁平存放,靠下面的视图检索);整合入口 [[投资方法论合集]]、[[投资方法论合集-核验与归档记录|核验与归档]]'
    assert old_entry in home
    changes['Home.md'] = home.replace(old_entry, '- `方法论/` — 全部方法论文章，扁平存放；[[投资方法论合集|二十篇独立方法论导航]]按研究、估值、周期、风险与执行展开。其他文章仍可在下方视图检索。')
    canvas = (VAULT / '投资方法论体系.canvas').read_text()
    for node_id, n in CONFIG['canvas_targets'].items():
        matching = [line for line in canvas.splitlines() if f'"id":"{node_id}"' in line]
        assert len(matching) == 1
        line = matching[0]
        target = NAV if n == 0 else TITLES[n-1]
        new_line = re.sub(r'"file":"方法论/投资方法论合集.md"', f'"file":"方法论/{target}.md"', line)
        new_line = re.sub(r',"subpath":"[^"]+"', '', new_line)
        canvas = canvas.replace(line, new_line)
    json.loads(canvas)
    changes['投资方法论体系.canvas'] = canvas
    changes['杂记/投资方法论合集-核验与归档记录.md'] = '''---
type: 杂记
author:
date: 2026-09-14
tags:
  - 投资体系
aliases: []
rating:
---

# 方法论版本与归档

阅读入口：[[投资方法论合集|二十篇独立方法论导航]]。

归档保留两个层次，均为可解压恢复的 ZIP，不会作为散落日记重新进入主库：

- [[methodology-source-20260914.zip|完整历史文章归档]]：138篇专栏文章、2份旧索引及原迁移清单，保持不变。
- [[methodology-rewrite-workpapers-20260914.zip|旧合集与本轮工作记录]]：重写前合集、旧核验页及受影响入口文件的可恢复副本；另含逐篇覆盖、案例取舍、行情返回、事实核验和审阅记录。

恢复旧版本时，先将 ZIP 解压到库外目录，根据归档中的文件清单选择需要的文件；不要直接整包覆盖当前库。其他作者文章和独立访谈正文未纳入重写范围，仅在相关区更新已失效的跳转。

## 相关

- 概念：[[投资体系]]
- [[投资方法论合集]] — 当前阅读导航。
'''
    return changes

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', action='store_true', help='Create recoverable previous-version ZIP once.')
    args = parser.parse_args()
    changes = build()
    staging = WORK / 'staged'
    staging.mkdir(exist_ok=True)
    for relative, text in changes.items():
        destination = staging / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(text)
    manifest = []
    patch = ['*** Begin Patch']
    for relative, new in changes.items():
        path = VAULT / relative
        old = path.read_text() if path.exists() else None
        manifest.append({'path': relative, 'before_sha256': sha(path.read_bytes()) if path.exists() else None, 'after_sha256': sha(new.encode())})
        if old is None:
            patch += [f'*** Add File: {path}'] + ['+' + x for x in new.splitlines()]
        else:
            patch += [f'*** Update File: {path}', '@@'] + ['-' + x for x in old.splitlines()] + ['+' + x for x in new.splitlines()]
    patch.append('*** End Patch')
    (WORK / 'migration.patch').write_text('\n'.join(patch) + '\n')
    (WORK / 'migration-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    bodies = {str(p.relative_to(VAULT)): sha(p.read_text().split('\n## 相关\n')[0].encode()) for p in (VAULT / '方法论').glob('*.md') if p.stem != NAV}
    (WORK / 'unchanged-bodies.json').write_text(json.dumps(bodies, ensure_ascii=False, indent=2))
    if args.archive:
        destination = VAULT / ARCHIVE
        assert not destination.exists(), 'Do not overwrite an existing recovery archive.'
        with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED) as archive:
            for item in manifest:
                path = VAULT / item['path']
                if path.exists():
                    archive.write(path, 'previous_version/' + item['path'])
            archive.writestr('migration-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            archive.writestr('unchanged-bodies.json', json.dumps(bodies, ensure_ascii=False, indent=2))
        with zipfile.ZipFile(destination) as archive:
            assert archive.testzip() is None
        print(f'Created recovery archive: {destination}')
    print(f'Prepared {len(changes)} file changes in {WORK / "migration.patch"}')

if __name__ == '__main__':
    main()
